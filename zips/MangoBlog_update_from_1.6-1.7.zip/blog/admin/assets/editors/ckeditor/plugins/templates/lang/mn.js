﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'mn', {
	button: 'Загварууд',
	emptyListMsg: '(Загвар тодорхойлогдоогүй байна)',
	insertOption: 'Одоогийн агууллагыг дарж бичих',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Загварыг нээж editor-рүү сонгож оруулна уу<br />(Одоогийн агууллагыг устаж магадгүй):',
	title: 'Загварын агуулга'
});

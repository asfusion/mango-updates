﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'zh', {
	button: '樣版',
	emptyListMsg: '(無樣版)',
	insertOption: '取代原有內容',
	options: 'Template Options', // MISSING
	selectPromptMsg: '請選擇欲開啟的樣版<br> (原有的內容將會被清除):',
	title: '內容樣版'
});

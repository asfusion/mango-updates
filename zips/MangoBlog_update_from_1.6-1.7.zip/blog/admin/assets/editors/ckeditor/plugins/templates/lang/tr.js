﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'tr', {
	button: 'Şablonlar',
	emptyListMsg: '(Belirli bir şablon seçilmedi)',
	insertOption: 'Mevcut içerik ile değiştir',
	options: 'Şablon Seçenekleri',
	selectPromptMsg: 'Düzenleyicide açmak için lütfen bir şablon seçin.<br>(hali hazırdaki içerik kaybolacaktır.):',
	title: 'İçerik Şablonları'
});

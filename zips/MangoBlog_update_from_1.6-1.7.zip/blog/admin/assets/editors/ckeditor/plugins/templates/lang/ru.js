﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'ru', {
	button: 'Шаблоны',
	emptyListMsg: '(не определено ни одного шаблона)',
	insertOption: 'Заменить текущее содержимое',
	options: 'Параметры шаблона',
	selectPromptMsg: 'Пожалуйста, выберите, какой шаблон следует открыть в редакторе',
	title: 'Шаблоны содержимого'
});

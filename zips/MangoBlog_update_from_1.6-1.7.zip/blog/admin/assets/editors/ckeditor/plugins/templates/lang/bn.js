﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'bn', {
	button: 'টেমপ্লেট',
	emptyListMsg: '(কোন টেমপ্লেট ডিফাইন করা নেই)',
	insertOption: 'Replace actual contents', // MISSING
	options: 'Template Options', // MISSING
	selectPromptMsg: 'অনুগ্রহ করে এডিটরে ওপেন করার জন্য টেমপ্লেট বাছাই করুন<br>(আসল কনটেন্ট হারিয়ে যাবে):',
	title: 'কনটেন্ট টেমপ্লেট'
});

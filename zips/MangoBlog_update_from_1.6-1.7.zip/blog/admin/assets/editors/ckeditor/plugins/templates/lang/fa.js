﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'fa', {
	button: 'الگوها',
	emptyListMsg: '(الگوئی تعریف نشده است)',
	insertOption: 'محتویات کنونی جایگزین شوند',
	options: 'گزینههای الگو',
	selectPromptMsg: 'لطفا الگوی موردنظر را برای بازکردن در ویرایشگر برگزینید<br>(محتویات کنونی از دست خواهند رفت):',
	title: 'الگوهای محتویات'
});

﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'sv', {
	button: 'Sidmallar',
	emptyListMsg: '(Ingen mall är vald)',
	insertOption: 'Ersätt aktuellt innehåll',
	options: 'Inställningar för mall',
	selectPromptMsg: 'Var god välj en mall att använda med editorn<br>(allt nuvarande innehåll raderas):',
	title: 'Sidmallar'
});

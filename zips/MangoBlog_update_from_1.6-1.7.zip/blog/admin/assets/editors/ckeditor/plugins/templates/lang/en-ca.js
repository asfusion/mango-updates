﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'en-ca', {
	button: 'Templates',
	emptyListMsg: '(No templates defined)',
	insertOption: 'Replace actual contents',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Please select the template to open in the editor',
	title: 'Content Templates'
});

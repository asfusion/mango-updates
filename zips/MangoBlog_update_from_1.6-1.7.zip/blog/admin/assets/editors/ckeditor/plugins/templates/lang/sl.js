﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'sl', {
	button: 'Predloge',
	emptyListMsg: '(Ni pripravljenih predlog)',
	insertOption: 'Zamenjaj trenutno vsebino',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Izberite predlogo, ki jo želite odpreti v urejevalniku<br>(trenutna vsebina bo izgubljena):',
	title: 'Vsebinske predloge'
});

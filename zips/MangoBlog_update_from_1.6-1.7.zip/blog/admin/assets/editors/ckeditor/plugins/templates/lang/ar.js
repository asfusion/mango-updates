﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'ar', {
	button: 'القوالب',
	emptyListMsg: '(لم يتم تعريف أي قالب)',
	insertOption: 'استبدال المحتوى',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'اختر القالب الذي تود وضعه في المحرر',
	title: 'قوالب المحتوى'
});

﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'th', {
	button: 'เทมเพลต',
	emptyListMsg: '(ยังไม่มีการกำหนดเทมเพลต)',
	insertOption: 'แทนที่เนื้อหาเว็บไซต์ที่เลือก',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'กรุณาเลือก เทมเพลต เพื่อนำไปแก้ไขในอีดิตเตอร์<br />(เนื้อหาส่วนนี้จะหายไป):',
	title: 'เทมเพลตของส่วนเนื้อหาเว็บไซต์'
});

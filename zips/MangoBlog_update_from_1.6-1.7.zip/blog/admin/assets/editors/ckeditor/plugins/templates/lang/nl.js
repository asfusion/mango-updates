﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'nl', {
	button: 'Sjablonen',
	emptyListMsg: '(Geen sjablonen gedefinieerd)',
	insertOption: 'Vervang de huidige inhoud',
	options: 'Template opties',
	selectPromptMsg: 'Selecteer het sjabloon dat in de editor geopend moet worden (de actuele inhoud gaat verloren):',
	title: 'Inhoud sjablonen'
});

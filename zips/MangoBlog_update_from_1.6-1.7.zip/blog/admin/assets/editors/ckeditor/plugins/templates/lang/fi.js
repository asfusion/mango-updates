﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'fi', {
	button: 'Pohjat',
	emptyListMsg: '(Ei määriteltyjä pohjia)',
	insertOption: 'Korvaa editorin koko sisältö',
	options: 'Sisältöpohjan ominaisuudet',
	selectPromptMsg: 'Valitse pohja editoriin<br>(aiempi sisältö menetetään):',
	title: 'Sisältöpohjat'
});

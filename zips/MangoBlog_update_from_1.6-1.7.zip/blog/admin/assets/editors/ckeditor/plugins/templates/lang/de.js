﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'de', {
	button: 'Vorlagen',
	emptyListMsg: '(keine Vorlagen definiert)',
	insertOption: 'Aktuellen Inhalt ersetzen',
	options: 'Vorlagen Optionen',
	selectPromptMsg: 'Klicken Sie auf eine Vorlage, um sie im Editor zu öffnen (der aktuelle Inhalt wird dabei gelöscht!):',
	title: 'Vorlagen'
});

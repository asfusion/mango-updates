﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'hr', {
	button: 'Predlošci',
	emptyListMsg: '(Nema definiranih predložaka)',
	insertOption: 'Zamijeni trenutne sadržaje',
	options: 'Opcije predložaka',
	selectPromptMsg: 'Molimo odaberite predložak koji želite otvoriti<br>(stvarni sadržaj će biti izgubljen):',
	title: 'Predlošci sadržaja'
});

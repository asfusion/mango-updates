﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'templates', 'fr-ca', {
	button: 'Modèles',
	emptyListMsg: '(Aucun modèle disponible)',
	insertOption: 'Remplacer tout le contenu actuel',
	options: 'Template Options', // MISSING
	selectPromptMsg: 'Sélectionner le modèle à ouvrir dans l\'éditeur<br>(le contenu actuel sera remplacé):',
	title: 'Modèles de contenu'
});
